
<?php $__env->startSection('content'); ?>
		<!-- container -->
		<div class="container-fluid">
			<!-- /breadcrumb -->
			<br><br>
			<div class="row">
				<!-- آمار سفارش‌ها -->
					<div class="col-sm-6 col-lg-3 mb-4">
							<div class="card card-border-shadow-primary">
								<div class="card-body">
										<h5 class="card-title">تعداد کل سفارش‌ها: <?php echo e($totalOrders); ?></h5>
										<p class="mb-1">در حال بررسی: <?php echo e($pendingOrders); ?></p>
										<p class="mb-1">تکمیل‌شده: <?php echo e($completedOrders); ?></p>
								</div>
							</div>
					</div>
					<!-- آمار پرداخت‌ها -->
					<div class="col-sm-6 col-lg-3 mb-4">
							<div class="card card-border-shadow-warning">
								<div class="card-body">
										<h5 class="card-title">مجموع پرداخت‌ها: <?php echo e(number_format($totalPayments, 0)); ?> تومان</h5>
										<p class="mb-1">موفق: <?php echo e(number_format($successfulPayments, 0)); ?> تومان</p>
										<p class="mb-1">تعداد پرداخت های ناموفق: <?php echo e($failedPayments); ?></p>
								</div>
							</div>
					</div>
					<!-- آمار کاربران -->
					<div class="col-sm-6 col-lg-3 mb-4">
							<div class="card card-border-shadow-danger">
									<div class="card-body">
											<h5 class="card-title">تعداد کل کاربران: <?php echo e($totalUsers); ?> نفر</h5>
											<p class="mb-1">کاربران امروز: <?php echo e($getusertoday); ?> نفر</p>
											<p class="mb-1">کاربران فعال: <?php echo e($getusertoday); ?> نفر</p>
									</div>
							</div>
					</div>
					<!-- آمار محصولات -->
					<div class="col-sm-6 col-lg-3 mb-4">
							<div class="card card-border-shadow-info">
								<div class="card-body">
										<h5 class="card-title">تعداد کل محصولات: <?php echo e($totalProducts); ?></h5>
										<p class="mb-1">درآمد ماه جاری: <?php echo e(number_format($monthlyRevenue, 0)); ?> تومان</h5>
										<p class="mb-1">تعداد کل تیکت ها: <?php echo e($totaltickets); ?></h5>
								</div>
							</div>
					</div>
			</div>
			<!--/ Card Border Shadow -->
			<!-- On route vehicles Table -->
			<div class="row">
			<div class="col-lg-6 mb-4 mb-lg-0">
						<div class="card h-100">
								<div class="card-header d-flex justify-content-between">
										<h5 class="card-title m-0 me-2">آخرین پرداخت&zwnj;ها</h5>
								</div>
								<div class="table-responsive">
										<table class="table table-borderless border-top">
												<thead class="border-bottom">
												<tr>
													<th>مبلغ</th>
													<th>وضعیت</th>
													<th>تاریخ پرداخت</th>
												</tr>
												</thead>
												<tbody>
													<?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr role="row" class="odd">
														<td><?php echo e(number_format($payment->amount)); ?> تومان</td>
														<td>
															<?php if($payment->status === 'pending'): ?>
																	<span class="badge bg-warning">در انتظار پرداخت</span>
															<?php elseif($payment->status === 'confirmed'): ?>
																	<span class="badge bg-success">پرداخت شده</span>
															<?php else: ?>
																	<span class="badge bg-secondary">نامشخص</span>
															<?php endif; ?>
														</td>
														<td><?php echo e(\Hekmatinasser\Verta\Verta::instance($payment->created_at)->formatJalaliDatetime()); ?></td>
													</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php if(count($payments) == 0): ?>
												<tr><td colspan="7" style="text-align: center">هیچ پرداختی تاکنون ثبت نکرده اید!</td></tr>
												<?php endif; ?>
												</tbody>
										</table>
								</div>
						</div>
				</div>

				<div class="col-lg-6 mb-4 mb-lg-0">
							<div class="card h-100">
									<div class="card-header d-flex justify-content-between">
											<h5 class="card-title m-0 me-2">آخرین سفارش ها</h5>
									</div>
									<div class="table-responsive">
											<table class="table table-borderless border-top">
													<thead class="border-bottom">
													<tr>
														<th>محصولات</th>
														<th>مجموع قیمت</th>
														<th>وضعیت</th>
														<th>تاریخ</th>
													</tr>
													</thead>
													<tbody>
														<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr role="row" class="odd">
																<td>
																		<ul>
																				<?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																						<li><?php echo e($item->product->name); ?></li>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																		</ul>
																</td>
																<td><?php echo e(number_format($order->total_price)); ?> تومان</td>
																<td>
																	<?php if($order->status === 'pending'): ?>
																			<span class="badge bg-warning">در انتظار پرداخت</span>
																	<?php elseif($order->status === 'confirmed'): ?>
																			<span class="badge bg-success">پرداخت شده</span>
																	<?php else: ?>
																			<span class="badge bg-secondary">نامشخص</span>
																	<?php endif; ?>
																</td>
																<td><?php echo e(\Hekmatinasser\Verta\Verta::instance($order->created_at)->formatJalaliDatetime()); ?></td>
														</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php if(count($orders) == 0): ?>
													<tr><td colspan="7" style="text-align: center">هیچ سفارشی تاکنون ثبت نکرده اید!</td></tr>
													<?php endif; ?>
													</tbody>
											</table>
									</div>
							</div>
					</div>
			</div>
			<!--/ On route vehicles Table -->
			<br>
			<!-- On route vehicles Table -->
			<div class="row">
			<div class="col-lg-6 mb-4 mb-lg-0">
						<div class="card h-100">
								<div class="card-header d-flex justify-content-between">
										<h5 class="card-title m-0 me-2">آخرین کاربران</h5>
								</div>
								<div class="table-responsive">
										<table class="table table-borderless border-top">
												<thead class="border-bottom">
												<tr>
													<th>نام</th>
													<th>ایمیل</th>
													<th>وضعیت</th>
													<th>تاریخ عضویت</th>
												</tr>
												</thead>
												<tbody>
													<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr role="row" class="odd">
														<td><?php echo e($user->name); ?></td>
														<td><?php echo e($user->email); ?></td>
														<td>
															<?php if($user->status === 'else'): ?>
																	<span class="badge bg-success">فعال</span>
															<?php else: ?>
																	<span class="badge bg-warning">غیرفعال</span>
															<?php endif; ?>
														</td>
														<td><?php echo e(\Hekmatinasser\Verta\Verta::instance($user->created_at)->formatJalaliDatetime()); ?></td>
													</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</tbody>
										</table>
								</div>
						</div>
				</div>

				<div class="col-lg-6 mb-4 mb-lg-0">
							<div class="card h-100">
									<div class="card-header d-flex justify-content-between">
											<h5 class="card-title m-0 me-2">آخرین تیکت ها</h5>
									</div>
									<div class="table-responsive">
											<table class="table table-borderless border-top">
													<thead class="border-bottom">
													<tr>
														<th>عنوان</th>
														<th>وضعیت</th>
														<th>تاریخ</th>
													</tr>
													</thead>
													<tbody>
														<?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                  <tr  role="row" class="odd">
															<td><?php echo e($ticket->title); ?></td>
															<td>
																<?php if($ticket->status === 'open'): ?>
																	<span class="badge bg-success">باز</span>
															<?php elseif($ticket->status === 'closed'): ?>
																	<span class="badge bg-danger">بسته</span>
															<?php else: ?>
																	<span class="badge bg-warning">نامشخص</span>
															<?php endif; ?>
														</td>
														<td><?php echo e(\Hekmatinasser\Verta\Verta::instance($ticket->created_at)->formatJalaliDatetime()); ?></td>
														</tr>
					                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php if(count($tickets) == 0): ?>
					                  <tr>
					                    <td colspan="7" style="text-align: center">تیکتی موجود نیست!</td>
					                  </tr>
					                  <?php endif; ?>
													</tbody>
											</table>
									</div>
							</div>
					</div>
			</div>
			<!--/ On route vehicles Table -->
		</div>
		<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

		<!--Internal Echart Plugin -->
<script src="assets/plugins/echart/echart.js"></script>
<script src="assets/js/echarts.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAGHIBI\Desktop\New folder\pacto\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>