<header id="topnav" class="defaultscroll sticky">
		<div class="container">
				<div><a class="logo" href="/"><img src="/assets/img/logo.png" height="24" alt=""></a></div>
				<div class="buy-button"><a href="/login" class="btn btn-primary">ورود به پنل کاربری </a></div>
				<div class="menu-extras">
						<div class="menu-item">
								<a class="navbar-toggle" id="isToggle" onclick="toggleMenu()">
										<div class="lines">
												<span></span>
												<span></span>
												<span></span>
										</div>
								</a>
						</div>
				</div>
				<div id="navigation">
						<ul class="navigation-menu">
								<li><a href="/" class="sub-menu-item">صفحه اصلی</a></li>
								<li><a href="/services" class="sub-menu-item">خدمات ما</a></li>
								<li><a href="/projects" class="sub-menu-item">پروژه ها</a></li>
								<li><a href="/blog" class="sub-menu-item">وبلاگ</a></li>
								<li><a href="/about" class="sub-menu-item">درباره ما</a></li>
								<li><a href="/contact" class="sub-menu-item">تماس با ما</a></li>
						</ul><!--end navigation menu-->
						<div class="buy-menu-btn d-none">
								<a href="/login" target="_blank" class="btn btn-primary">ورود به پنل کاربری </a>
						</div>
				</div>
		</div>
</header>
<?php /**PATH C:\Users\NAGHIBI\Desktop\New folder\pacto\resources\views/layouts/header.blade.php ENDPATH**/ ?>