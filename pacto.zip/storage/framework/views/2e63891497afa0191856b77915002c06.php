
<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <h3>مدیریت پرداخت‌ها</h3>

    <!-- فیلتر پرداخت‌ها -->
    <form method="GET" action="<?php echo e(route('admin.payments.index')); ?>" class="mb-4">
        <div class="row">
            <div class="col-md-4">
                <select name="status" class="form-select">
                    <option value="all" <?php echo e(request('status') == 'all' ? 'selected' : ''); ?>>همه وضعیت‌ها</option>
                    <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>در انتظار</option>
                    <option value="paid" <?php echo e(request('status') == 'paid' ? 'selected' : ''); ?>>پرداخت شده</option>
                    <option value="failed" <?php echo e(request('status') == 'failed' ? 'selected' : ''); ?>>ناموفق</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary">فیلتر</button>
            </div>
        </div>
    </form>

    <!-- جدول پرداخت‌ها -->
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>کاربر</th>
                        <th>مبلغ</th>
                        <th>وضعیت</th>
                        <th>تاریخ پرداخت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($payment->id); ?></td>
                            <td><?php echo e($payment->user->name); ?></td>
                            <td><?php echo e(number_format($payment->amount)); ?> تومان</td>
                            <td>
                                <?php if($payment->status === 'pending'): ?>
                                    <span class="badge bg-warning">در انتظار</span>
                                <?php elseif($payment->status === 'paid'): ?>
                                    <span class="badge bg-success">پرداخت شده</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">ناموفق</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($payment->created_at)->formatJalaliDatetime()); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('admin.payments.updateStatus', $payment)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <select name="status" class="form-select d-inline w-auto" onchange="this.form.submit()">
                                        <option value="pending" <?php echo e($payment->status == 'pending' ? 'selected' : ''); ?>>در انتظار</option>
                                        <option value="paid" <?php echo e($payment->status == 'paid' ? 'selected' : ''); ?>>پرداخت شده</option>
                                        <option value="failed" <?php echo e($payment->status == 'failed' ? 'selected' : ''); ?>>ناموفق</option>
                                    </select>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">هیچ پرداختی یافت نشد.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- صفحه‌بندی -->
            <div class="mt-3">
                <?php echo e($payments->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAGHIBI\Desktop\New folder\pacto\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>