
<?php $__env->startSection('content'); ?>

<style>
     /* Custom Table Styling */
     .custom-table {
      border-collapse: separate;
      border-spacing: 0;
      border: 1px solid #dee2e6;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .custom-table thead {
      background-color: #f8f9fa;
    }

    .custom-table thead th {
      text-align: center;
      font-weight: bold;
      color: #495057;
    }

    .custom-table tbody tr:hover {
      background-color: #e9ecef;
    }

    .custom-table td,
    .custom-table th {
      padding: 12px 15px;
      text-align: center;
      vertical-align: middle;
      border: 1px solid #dee2e6;
    }

    /* Add striped effect for rows */
    .custom-table tbody tr:nth-child(odd) {
      background-color: #f8f9fa;
    }
    .checkbox-wrapper-17 input[type=checkbox] {
    height: 0;
    width: 0;
    visibility: hidden;
  }
  .checkbox-wrapper-2 .ikxBAC {
    appearance: none;
    background-color: #dfe1e4;
    border-radius: 72px;
    border-style: none;
    flex-shrink: 0;
    height: 20px;
    margin: 0;
    position: relative;
    width: 30px;
  }

  .checkbox-wrapper-2 .ikxBAC::before {
    bottom: -6px;
    content: "";
    left: -6px;
    position: absolute;
    right: -6px;
    top: -6px;
  }

  .checkbox-wrapper-2 .ikxBAC,
  .checkbox-wrapper-2 .ikxBAC::after {
    transition: all 100ms ease-out;
  }

  .checkbox-wrapper-2 .ikxBAC::after {
    background-color: #fff;
    border-radius: 50%;
    content: "";
    height: 14px;
    left: 3px;
    position: absolute;
    top: 3px;
    width: 14px;
  }

  .checkbox-wrapper-2 input[type=checkbox] {
    cursor: default;
  }

  .checkbox-wrapper-2 .ikxBAC:hover {
    background-color: #c9cbcd;
    transition-duration: 0s;
  }

  .checkbox-wrapper-2 .ikxBAC:checked {
    background-color: #6e79d6;
  }

  .checkbox-wrapper-2 .ikxBAC:checked::after {
    background-color: #fff;
    left: 13px;
  }

  .checkbox-wrapper-2 :focus:not(.focus-visible) {
    outline: 0;
  }

  .checkbox-wrapper-2 .ikxBAC:checked:hover {
    background-color: #535db3;
  }

</style>
<div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-12">
                <h5>ساخت کمپین تبلیغاتی</h5>
            </div>
            <div class="col-12 mb-4">
                <div class="bs-stepper wizard-numbered mt-2">
                    <div class="bs-stepper-header">
                        <div class="step active" data-target="#step1">
                            <button class="step-trigger" type="button" aria-selected="true">
                                <span class="bs-stepper-circle">1</span>
                                <span class="bs-stepper-label">
                                    <span class="bs-stepper-title">جزئیات کمپین</span>
                                    <span class="bs-stepper-subtitle">تنظیم جزئیات کمپین</span>
                                </span>
                            </button>
                        </div>
                        <div class="line">
                            <i class="ti ti-chevron-right"></i>
                        </div>
                        <div class="step" data-target="#step2">
                            <button class="step-trigger" type="button" aria-selected="false">
                                <span class="bs-stepper-circle">2</span>
                                <span class="bs-stepper-label">
                                    <span class="bs-stepper-title">انتخاب محصولات</span>
                                    <span class="bs-stepper-subtitle">انتخاب محصولات تبلیغاتی برای کمپین</span>
                                </span>
                            </button>
                        </div>
                        <div class="line">
                            <i class="ti ti-chevron-right"></i>
                        </div>
                        <div class="step" data-target="#step3">
                            <button class="step-trigger" type="button" aria-selected="false">
                                <span class="bs-stepper-circle">3</span>
                                <span class="bs-stepper-label">
                                    <span class="bs-stepper-title">اهداف و ثبت نهایی</span>
                                    <span class="bs-stepper-subtitle">هدف کمپین و ثبت نهایی</span>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="bs-stepper-content">
                          <form action="<?php echo e(route('user.campaigns.store')); ?>" method="POST" onsubmit="prepareSelectedProducts()">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" id="selectedProductsInput" name="selected_products">
                            <!-- Step 1: Campaign Details -->
                            <div class="content active dstepper-block" id="step1">
                                <div class="content-header mb-3">
                                    <h6 class="mb-0">جزئیات کمپین</h6>
                                    <small>اطلاعات مربوط به کمپین خود را وارد کنید</small>
                                </div>
                                <div class="row g-3">
                                    <div class="col-sm-6">
                                        <label class="form-label" for="name">نام کمپین</label>
                                        <input class="form-control" id="name" placeholder="نام کمپین" type="text" name="name" required>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label" for="description">توضیحات کمپین</label>
                                        <textarea class="form-control" id="description" placeholder="توضیحات کمپین" name="description" required></textarea>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label" for="start-date">تاریخ شروع کمپین</label>
                                        <input class="form-control" id="start-date" type="text" name="start_date" required>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label" for="end-date">تاریخ پایان کمپین</label>
                                        <input class="form-control" id="end-date" type="text" name="end_date" required>
                                    </div>
                                    <div class="col-12 d-flex justify-content-between">
                                        <button class="btn btn-label-secondary btn-prev waves-effect" disabled="">
                                            <i class="ti ti-arrow-left me-sm-1 me-0"></i>
                                            <span class="align-middle d-sm-inline-block d-none">قبلی</span>
                                        </button>
                                        <button class="btn btn-primary btn-next waves-effect waves-light">
                                            <span class="align-middle d-sm-inline-block d-none me-sm-1">بعدی</span>
                                            <i class="ti ti-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Step 2: Product Selection -->
                            <div class="content" id="step2">
                              <div class="content-header mb-3">
                                  <h6 class="mb-0">انتخاب محصولات</h6>
                                  <small>دسته‌بندی‌ها و محصولات مورد نظر برای کمپین را انتخاب کنید.</small>
                              </div>
                              <div class="row g-3">
                                  <!-- Select for Categories -->
                                  <div class="col-6">
                                      <label class="form-label" for="categories">دسته‌بندی‌ها</label>
                                      <select class="form-select" id="categories">
                                          <option value="" disabled selected>انتخاب دسته‌بندی</option>
                                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div>

                                  <!-- Select for Product Types -->
                                  <div class="col-6">
                                      <label class="form-label" for="productType">نوع محصول</label>
                                      <select class="form-select" id="productType">
                                          <option value="" disabled selected>انتخاب نوع محصول</option>
                                          <option value="view_based">بازدیدی</option>
                                          <option value="fixed">تعرفه‌ای</option>
                                          <option value="package">پکیج</option>
                                      </select>
                                  </div>

                                  <!-- Products Table -->
                                  <div class="col-12 mt-3">
                                      <label class="form-label">محصولات:</label>
                                      <div id="productsTable" class="table-responsive">
                                          <table class="table custom-table table-bordered">
                                              <thead>
                                                  <tr>
                                                      <th>نام محصول</th>
                                                      <th>قیمت</th>
                                                      <th>انتخاب</th>
                                                  </tr>
                                              </thead>
                                              <tbody>
                                                  <!-- محصولات به صورت داینامیک با جاوااسکریپت اینجا اضافه می‌شوند -->
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>

                                  <!-- Navigation Buttons -->
                                  <div class="col-12 d-flex justify-content-between">
                                      <button class="btn btn-label-secondary btn-prev waves-effect">
                                          <i class="ti ti-arrow-left me-sm-1 me-0"></i>
                                          <span class="align-middle d-sm-inline-block d-none">قبلی</span>
                                      </button>
                                      <button class="btn btn-primary btn-next waves-effect waves-light">
                                          <span class="align-middle d-sm-inline-block d-none me-sm-1">بعدی</span>
                                          <i class="ti ti-arrow-right"></i>
                                      </button>
                                  </div>
                              </div>
                          </div>

                            <!-- Step 3: Campaign Objectives and Final Submission -->
                            <div class="content" id="step3">
                                <div class="content-header mb-3">
                                    <h6 class="mb-0">اهداف و ثبت نهایی</h6>
                                    <small>هدف و جزئیات تکمیلی کمپین را وارد کنید</small>
                                </div>
                                <div class="row g-3">
                                    <div class="col-sm-6">
                                        <label class="form-label" for="goal">اهداف کمپین</label>
                                        <textarea class="form-control" id="goal" placeholder="اهداف کمپین" name="goal" required></textarea>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label" for="message">نکات مهم کمپین</label>
                                        <textarea class="form-control" id="message" placeholder="نکات مهم" name="message"></textarea>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label" for="content-link">لینک محتوا</label>
                                        <input class="form-control" id="content_link" placeholder="لینک محتوا" type="url" name="content_link">
                                    </div>
                                    <div class="col-12 d-flex justify-content-between">
                                        <button class="btn btn-label-secondary btn-prev waves-effect">
                                            <i class="ti ti-arrow-left me-sm-1 me-0"></i>
                                            <span class="align-middle d-sm-inline-block d-none">قبلی</span>
                                        </button>
                                        <button class="btn btn-success btn-submit waves-effect waves-light" type="submit">
                                            ثبت نهایی
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAGHIBI\Desktop\New folder\pacto\resources\views/user/campaign/create-layout.blade.php ENDPATH**/ ?>