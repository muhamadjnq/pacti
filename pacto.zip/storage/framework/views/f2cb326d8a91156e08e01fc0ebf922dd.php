
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
                <!-- Content -->
                <div class="flex-grow-1 container-p-y container-fluid">
                    <div class="row">
                        <div class="col-sm-6 col-lg-3 mb-4">
                            <div class="card card-border-shadow-primary">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-2 pb-1">
                                        <div class="avatar me-2">
                                            <span class="avatar-initial rounded bg-label-primary">
                                                <i class="ti ti-truck ti-md"></i>
                                            </span>
                                        </div>
                                        <h4 class="ms-1 mb-0"><?php echo e($totalOrders); ?></h4>
                                    </div>
                                    <p class="mb-1">تعداد سفارشات</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3 mb-4">
                            <div class="card card-border-shadow-warning">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-2 pb-1">
                                        <div class="avatar me-2">
                                            <span class="avatar-initial rounded bg-label-warning">
                                                <i class="ti ti-alert-triangle ti-md"></i>
                                            </span>
                                        </div>
                                        <h4 class="ms-1 mb-0"><?php echo e(number_format($totalPayments, 0)); ?> تومان</h4>
                                    </div>
                                    <p class="mb-1">مجموع پرداخت ها</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3 mb-4">
                            <div class="card card-border-shadow-danger">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-2 pb-1">
                                        <div class="avatar me-2">
                                            <span class="avatar-initial rounded bg-label-danger">
                                                <i class="ti ti-git-fork ti-md"></i>
                                            </span>
                                        </div>
                                        <h4 class="ms-1 mb-0"><?php echo e(count($tickets)); ?></h4>
                                    </div>
                                    <p class="mb-1">تیکت ها</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3 mb-4">
                            <div class="card card-border-shadow-info">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-2 pb-1">
                                        <div class="avatar me-2">
                                            <span class="avatar-initial rounded bg-label-info">
                                                <i class="ti ti-clock ti-md"></i>
                                            </span>
                                        </div>
                                        <h4 class="ms-1 mb-0">0</h4>
                                    </div>
                                    <p class="mb-1">کمپین ها</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="content-wrapper">
                      <?php $__currentLoopData = $categoriess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mb-4">
                                <?php $__currentLoopData = $category->random_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-sm-6 col-lg-3 mb-4">
                                    <div class="card">
                                        <div class="card-body text-center">
                                          <div class="d-flex align-items-start">
                                          <div class="d-flex align-items-start avatar avatar-xl me-3">
                                            <img alt="<?php echo e($product->name); ?>" class="rounded-circle" src="<?php echo e(asset('storage/' . $product->image)); ?>" style="width: 40px;height:40px;">
                                          </div>
                                          <h6 class="mb-0"><?php echo e($product->title); ?></h5>
                                          </div>
                                            <small class="text-muted d-block"><?php echo e($product->description); ?></small>
                                            <p class="mb-0 fw-medium">قیمت: <?php echo e(number_format($product->price, 0)); ?> تومان</p>
                                            <form action="<?php echo e(route('user.products.order', $product->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input hidden class="form-control" value="1" min="1" type="number" name="quantity">
                                                <button class="btn btn-primary waves-effect waves-light" data-bs-target="#pricingModal" data-bs-toggle="modal" type="submit"> ثبت سفارش</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> -->
                    <div class="row mb-5">
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-6 col-lg-4">
                          <div class="card mb-3">
                              <div class="card-body">
                                  <h5 class="card-title">سفارش تبلیغات <?php echo e($categorie->name); ?></h5>
                                  <p class="card-text"><?php echo e($categorie->description); ?></p>
                                  <a class="btn btn-primary waves-effect waves-light" href="/user/categories/<?php echo e($categorie->slug); ?>">ثبت سفارش</a>
                              </div>
                          </div>
                      </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!--/ Card Border Shadow -->
                    <div class="col-md-12 col-xl-12 col-lg-12 mb-4">
                            <div class="card h-100">
                                <div class="card-header d-flex justify-content-between">
                                    <div class="card-title m-0 me-2">
                                        <h5 class="m-0 me-2">کمپین های محبوب و موفق</h5>
                                    </div>
                                    <ul class="navbar-nav flex-row align-items-center ms-auto">
                                      <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                        <a class="nav-link dropdown-toggle hide-arrow" href="/user/campaign/example"><h6 class="m-0 me-2">مشاهده همه</h6></a>
                                      </li>
                                    </ul>
                                </div>
                                <hr>
                                <div class="card-body">
                                    <ul class="p-0 m-0">
                                      <div class="row">
                                      <?php $__currentLoopData = $campaignProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <div class="col-md-6 col-xl-3 mb-4">
                                        <li class="d-flex mb-4 pb-1">
                                            <div class="me-3">
                                                <img alt="<?php echo e($campaign->name); ?>" class="rounded" src="/assets/img/pacto-logo.jpg" width="46">
                                            </div>
                                            <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                                                <div class="me-2">
                                                    <h6 class="mb-0"><?php echo e($campaign->name); ?></h6>
                                                    <small class="text-muted d-block"><?php echo e($campaign->description); ?></small>
                                                </div>
                                                <div class="user-progress d-flex align-items-center gap-1">
                                                    <p class="mb-0 fw-medium">قیمت: <?php echo e(number_format($campaign->price, 0)); ?> تومان</p>
                                                </div>
                                                <form action="<?php echo e(route('user.orders.store')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="product_id" value="<?php echo e($campaign->id); ?>">
                                                    <input hidden class="form-control" value="1" min="1" type="number" name="quantity">
                                                    <button class="btn btn-primary waves-effect waves-light" data-bs-target="#pricingModal" data-bs-toggle="modal" type="submit"> ثبت سفارش</button>
                                                </form>
                                            </div>
                                            <hr>
                                        </li>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <!-- Card Border Shadow -->
                        <!-- On route vehicles Table -->
                        <div class="row">
                        <div class="col-lg-6 mb-4 mb-lg-0">
                              <div class="card h-100">
                                  <div class="card-header d-flex justify-content-between">
                                      <h5 class="card-title m-0 me-2">آخرین پرداخت&zwnj;ها</h5>
                                  </div>
                                  <div class="table-responsive">
                                      <table class="table table-borderless border-top">
                                          <thead class="border-bottom">
                                          <tr>
                                            <th>مبلغ</th>
                                            <th>وضعیت</th>
                                            <th>تاریخ پرداخت</th>
                                          </tr>
                                          </thead>
                                          <tbody>
                                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr role="row" class="odd">
                                              <td><?php echo e(number_format($payment->amount)); ?> تومان</td>
                                              <td>
                                                <?php if($payment->status === 'pending'): ?>
                                                    <span class="badge bg-warning">در انتظار پرداخت</span>
                                                <?php elseif($payment->status === 'confirmed'): ?>
                                                    <span class="badge bg-success">پرداخت شده</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">نامشخص</span>
                                                <?php endif; ?>
                                              </td>
                                              <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($payment->created_at)->formatJalaliDatetime()); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <?php if(count($payments) == 0): ?>
                                          <tr><td colspan="7" style="text-align: center">هیچ پرداختی تاکنون ثبت نکرده اید!</td></tr>
                                          <?php endif; ?>
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>

                          <div class="col-lg-6 mb-4 mb-lg-0">
                                <div class="card h-100">
                                    <div class="card-header d-flex justify-content-between">
                                        <h5 class="card-title m-0 me-2">آخرین سفارش ها</h5>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-borderless border-top">
                                            <thead class="border-bottom">
                                            <tr>
                                              <th>محصولات</th>
                                              <th>مجموع قیمت</th>
                                              <th>وضعیت</th>
                                              <th>تاریخ</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr role="row" class="odd">
                                                  <td>
                                                      <ul>
                                                          <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <li><?php echo e($item->product->name); ?></li>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </ul>
                                                  </td>
                                                  <td><?php echo e(number_format($order->total_price)); ?> تومان</td>
                                                  <td>
                                                    <?php if($order->status === 'pending'): ?>
                                                        <span class="badge bg-warning">در انتظار پرداخت</span>
                                                    <?php elseif($order->status === 'confirmed'): ?>
                                                        <span class="badge bg-success">پرداخت شده</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary">نامشخص</span>
                                                    <?php endif; ?>
                                                  </td>
                                                  <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($order->created_at)->formatJalaliDatetime()); ?></td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($orders) == 0): ?>
                                            <tr><td colspan="7" style="text-align: center">هیچ سفارشی تاکنون ثبت نکرده اید!</td></tr>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/ On route vehicles Table -->
                </div>
                <!-- / Content -->
                <div class="content-backdrop fade"></div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAGHIBI\Desktop\New folder\pacto\resources\views/user/dashboard/index.blade.php ENDPATH**/ ?>